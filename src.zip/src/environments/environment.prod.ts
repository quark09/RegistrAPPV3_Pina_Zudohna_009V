export const environment = {
  production: true,
  apiUrl: "http://jguzmanbozo.ddns.net:3300"
};
